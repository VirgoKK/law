# -*- coding: utf-8 -*-  
#import urllib2
#import urllib
from mongodb_queue import MogoQueue
from Download import request
from bs4 import BeautifulSoup

'''
def getHtml():
	page = urllib.urlopen("http://www.chinalawedu.com/falvfagui/")
	html = page.read()
	reg=r'class="fenlei_txt"'
	soup=BeautifulSoup(html,"lxml")
'''

tit_queue=MogoQueue('falvfagui', 'title_queue')
def start(url):
	response = request.get(url,3)
	soup=BeautifulSoup(response.text,'lxml')
	all_div = soup.find_all('div', class_="fenlei_txt")
	for div in all_div:
		all_a = div.find_all('a')
		for a in all_a:
			title = a.get_text()
			url = a['href']
			law_queue.push(url, title)  #������ȡ��ҳ�ͱ���д�����
		
		
	
if __name__ == "__main__":
	start("http://www.chinalawedu.com/falvfagui/")